MoYe 0.8.0 · HXi
Run: ./moye [file]
Architecture: x64. Requires glibc >= 2.35, GTK3 and WebKitGTK 4.1.
Ubuntu 22.04+/Debian 12+: install libwebkit2gtk-4.1-0, libgtk-3-0, zenity and xdg-utils.
Prefer the .deb package on Debian/Ubuntu to install runtime dependencies automatically.
Updates are checked in the app; Linux packages are installed manually.
