MoYe 0.9.1 · HXi
Run: ./moye [file]
Architecture: arm64. Requires glibc >= 2.35, GTK3 and WebKitGTK 4.1.
Ubuntu 22.04+/Debian 12+: install libwebkit2gtk-4.1-0, libgtk-3-0, zenity and xdg-utils.
Prefer the .deb package on Debian/Ubuntu to install runtime dependencies automatically.
Updates are checked in the app; Linux packages are installed manually.
